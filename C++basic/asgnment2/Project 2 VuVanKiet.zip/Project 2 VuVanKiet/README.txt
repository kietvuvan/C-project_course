Asignment 2:
Using Visual studio 2017.